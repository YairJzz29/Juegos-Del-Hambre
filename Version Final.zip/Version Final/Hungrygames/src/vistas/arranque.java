

package vistas;


public class arranque {

   
    
    public static void main(String[] args) {
        guardar abrir=new guardar();
        abrir.setVisible(true);
        abrir.setLocationRelativeTo(null);
        
        
    }
    
}
