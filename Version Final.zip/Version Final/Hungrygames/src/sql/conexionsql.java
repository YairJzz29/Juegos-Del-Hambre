
/*
package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class conexionsql {
    Connection conn=null;
    String url="jdbc:postgresql://localhost:5432/juegos";
    String usuario="postgres";
    String clave="12345";
    
    public Connection conectar(){
        try{
            Class.forName("org.postgresql.Driver");
            conn=DriverManager.getConnection(url,usuario,clave);
            
        }
        
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"Error al conectar"+e,"Error",JOptionPane.ERROR_MESSAGE);
            
        }
        
        return conn;
        
    }
    
}

*/

package sql;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class conexionsql {
    
    private static String user = "postgres"; //User de la BD
    private static String pswd = "12345"; //Password de la BD
    private static String bd = "juegos"; //Nombre de la BD
    private static String server = "jdbc:postgresql://localhost:5432/"+bd; //Llamando a nuestro server de BD
    private static String driver = "org.postgresql.Driver";//Driver que permite conectarse con PostgreSQL
    private static Connection con = null; //Para verificar la conexiÃ³n
    
    public Connection conectar() 
	{
		try
		{
			Class.forName(driver);
			con = (Connection)DriverManager.getConnection(server, user, 
					pswd);
			
			if(con != null)
			{
				System.out.println("La conexiÃ³n a la BD: "+ server +" "
						+ "se realizo al 100%");
			}
		}
		catch(SQLException ex)
		{
			System.out.println("Error al intentar conectarse a la BD"+ 
		server);
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println(ex);
		}
        return con;
	}	
	
	public ResultSet getQuery(String query)
	{
		Statement state = null;
		ResultSet result = null;
		
		try
		{
			state=(Statement) con.createStatement();
			result=state.executeQuery(query);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return result;
	}
	
	public void setQuery (String query)
	{
		Statement state = null;
		try
		{
			state = (Statement) con.createStatement();
			state.executeQuery(query);
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
	}
	
}

