package sql;

import getset.variables;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.ResultSet;
public class crudsql extends conexionsql {

//conexionsql con=new conexionsql(); //Este objecto es el encargado de hacer la conexion a la base de datos
    java.sql.Statement st;
    ResultSet rs;
    variables var=new variables();
    

    public void insertar(String nombre, String especialidad, String trabajo, String campeonatos, String tributos, String habitantes, String ubicacion, String clima, String hombres, String mujeres, String lider) {
        try {
            Connection conexion = conectar();
            st = conexion.createStatement();
            String sql = "insert into distrito(nombre,especialidad,trabajo,campeonatos,tributos,habitantes,ubicacion,clima,hombres,mujeres,lider) values('" + nombre + "','" + especialidad + "','" + trabajo + "','" + campeonatos + "','" + tributos + "','" + habitantes + "','" + ubicacion + "','" + clima + "','" + hombres + "','" + mujeres + "','" + lider + "');";
            st.execute(sql);
            st.close();
            conexion.close();
            JOptionPane.showMessageDialog(null, "El registro se guardo correctamente", "Mensaje", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null, "El registro no se guardo correctamente" + e, "Mensaje", JOptionPane.ERROR_MESSAGE);

        }
    }
    
    public void mostrar(String iddistrito){
        try{
            Connection conexion=conectar();
            st=conexion.createStatement();
            String sql="select * from distrito where iddistrito='"+iddistrito+"';";
            rs=st.executeQuery(sql);
            
            if (rs.next()){
                var.setIddistrito(rs.getString("iddistrito"));
                var.setNombre(rs.getString("nombre"));
                var.setEspecialidad(rs.getString("especialidad"));
                var.setTrabajo(rs.getString("trabajo"));
                var.setCampeonatos(rs.getString("campeonatos"));
                var.setTributos(rs.getString("tributos"));
                var.setHabitantes(rs.getString("habitantes"));
                var.setUbicacion(rs.getString("ubicacion"));
                var.setClima(rs.getString("clima"));
                var.setHombres(rs.getString("hombres"));
                var.setMujeres(rs.getString("mujeres"));
                var.setLider(rs.getString("lider"));
 
            } else{
                
                var.setIddistrito(rs.getString(""));
                var.setNombre(rs.getString(""));
                var.setEspecialidad(rs.getString(""));
                var.setTrabajo(rs.getString(""));
                var.setCampeonatos(rs.getString(""));
                var.setTributos(rs.getString(""));
                var.setHabitantes(rs.getString(""));
                var.setUbicacion(rs.getString(""));
                var.setClima(rs.getString(""));
                var.setHombres(rs.getString(""));
                var.setMujeres(rs.getString(""));
                var.setLider(rs.getString(""));
                JOptionPane.showMessageDialog(null, "No se encontro ningun registro","Sin resgistro",JOptionPane.INFORMATION_MESSAGE);
                
            }
            
            st.close();
            conexion.close();
           
            
        }
        catch (Exception e){
            JOptionPane.showMessageDialog(null,"No se encontro algun registro","Error de busqueda",JOptionPane.ERROR_MESSAGE);    
        }
        
    }
        
        public void actualizar(String nombre, String especialidad, String trabajo, String campeonatos, String tributos, String habitantes, String ubicacion, String clima, String hombres, String mujeres, String lider, String iddistrito){
            try{
                
                Connection conexion=conectar();
                st=conexion.createStatement();
                String sql="update distrito set nombre='"+nombre+"',especialidad='"+especialidad+"',trabajo='"+trabajo+"',campeonatos='"+campeonatos+"',tributos='"+tributos+"',habitantes='"+habitantes+"',ubicacion='"+ubicacion+"',clima='"+clima+"',hombres='"+hombres+"',mujeres='"+mujeres+"',lider='"+lider+"'where iddistrito='"+iddistrito+"'; ";
                st.executeUpdate(sql);
                st.close();
                conexion.close();
                JOptionPane.showMessageDialog(null, "El registro se realizo correctamente","Exito",JOptionPane.INFORMATION_MESSAGE);
                
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error al actualizar"+e,"Error",JOptionPane.ERROR_MESSAGE);            
            }
        
        }
        
        public void eliminar(String iddistrito){
            try {
                Connection conexion=conectar();
                st=conexion.createStatement();
                String sql="delete from distrito where iddistrito='"+iddistrito+"'; ";
                st.execute(sql);
                st.close();
                conexion.close();
                JOptionPane.showMessageDialog(null, "Registro eliminado", "Eliminado",JOptionPane.INFORMATION_MESSAGE);
            }
            catch (Exception e){
                JOptionPane.showMessageDialog(null, "Error al eliminar el registrto"+ e,"Error",JOptionPane.ERROR_MESSAGE);
                
            }       
        } 
    }
    
    
    
    
    
    
    
    
    
    


